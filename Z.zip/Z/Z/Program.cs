﻿using System.IO;

//1
string text = Console.ReadLine();
char[] chars4 = text.ToCharArray();
Console.WriteLine();
string word = Console.ReadLine();

char[] separators = ['.', '?', '!', ' ', ';', ':', ','];
string[] text2 = text.Split(separators, StringSplitOptions.RemoveEmptyEntries);

var result4 = from wrd in text2
                 where wrd.Equals(word, StringComparison.InvariantCultureIgnoreCase)
                 select wrd;

int wordCount = result4.Count();
Console.WriteLine(wordCount);

Console.ReadKey();
Console.Clear();


//2
string str = Console.ReadLine();
char[] chars = str.ToCharArray();

Console.WriteLine("\n1:");
var numinstr = from ch in str
                  where char.IsDigit(ch)
                  select ch;
Console.WriteLine("Кол-во: " + numinstr.Count());
foreach (char x in numinstr)
    Console.Write($"{x} ");


Console.WriteLine("\n\n2:");
var result = chars.TakeWhile(x => x != '/');
foreach (char x in result)
    Console.Write($"{x}");


Console.WriteLine("\n\n3:");
List<char> words = new List<char>();
char[] chars2 = new char[chars.Length];
for (int i = 0; i < chars2.Length; i++)
{
    chars2[i] = char.IsLower(str[i]) ? char.ToUpper(str[i]) : char.ToLower(str[i]);
}
var result3 = chars2.SkipWhile(x => x != '/');
foreach (char x in result3)
    Console.Write($"{x}");

StreamWriter sw = File.CreateText("file.txt");
foreach (char x in result3)
    sw.Write($"{x}");
sw.Close();

Console.ReadKey();